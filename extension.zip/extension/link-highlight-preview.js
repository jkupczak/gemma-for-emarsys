// link-highlight-preview.js — glow/pip overlays on links in the desktop preview iframe
(function () {
  'use strict';

  const IFRAME_SELECTOR = 'iframe.e-contentblocks-preview__iframe-desktop';
  const BUTTON_GROUP_SELECTOR = 'cb-campaign-preview .e-buttongroup';
  const ANCHOR_SELECTOR = 'cb-highlight-editables-switch';
  const OVERLAY_CONTAINER_ID = 'gem-link-highlight-overlay-container';
  const STYLE_ID = 'gem-link-highlight-styles';
  const STORAGE_OVERLAY_ACTIVE_KEY = 'gemLinkHighlightOverlayActive';
  const STORAGE_PREVIEW_ENABLED_KEY = 'gemLinkHighlightPreviewEnabled';
  const STORAGE_SHOW_URLS_KEY = 'gemLinkHighlightShowUrls';
  const LABEL_MIN_WIDTH_PX = 100;

  const SVG_LINK_EDITABLE =
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -960 960 960" aria-hidden="true">' +
    '<path fill="currentColor" d="M318-120q-82 0-140-58t-58-140q0-40 15-76t43-64l134-133 56 56-134 134q-17 17-25.5 38.5T200-318q0 49 34.5 83.5T318-200q23 0 45-8.5t39-25.5l133-134 57 57-134 133q-28 28-64 43t-76 15Zm79-220-57-57 223-223 57 57-223 223Zm251-28-56-57 134-133q17-17 25-38t8-44q0-50-34-85t-84-35q-23 0-44.5 8.5T558-726L425-592l-57-56 134-134q28-28 64-43t76-15q82 0 139.5 58T839-641q0 39-14.5 75T782-502L648-368Z"/>' +
    '</svg>';

  const SVG_LINK_LOCKED =
    '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 -960 960 960" aria-hidden="true">' +
    '<path fill="currentColor" d="M240-80q-33 0-56.5-23.5T160-160v-400q0-33 23.5-56.5T240-640h40v-80q0-83 58.5-141.5T480-920q83 0 141.5 58.5T680-720v80h40q33 0 56.5 23.5T800-560v400q0 33-23.5 56.5T720-80H240Zm0-80h480v-400H240v400Zm296.5-143.5Q560-327 560-360t-23.5-56.5Q513-440 480-440t-56.5 23.5Q400-393 400-360t23.5 56.5Q447-280 480-280t56.5-23.5ZM360-640h240v-80q0-50-35-85t-85-35q-50 0-85 35t-35 85v80ZM240-160v-400 400Z"/>' +
    '</svg>';

  const LINK_HIGHLIGHT_CSS = `
.gem-link-highlight-overlay {
  border-radius: 2px;
  overflow: visible;
  display: flex;
  align-items: center;
  justify-content: center;
}
.gem-link-highlight-overlay--editable {
  background: rgba(37, 99, 235, 0.12);
  box-shadow: inset 0 0 0 2px rgba(37, 99, 235, 0.55);
}
.gem-link-highlight-overlay--locked {
  background: rgba(147, 197, 253, 0.14);
  box-shadow: inset 0 0 0 2px rgba(147, 197, 253, 0.48);
}
.gem-link-highlight-pip {
  position: absolute;
  top: -5px;
  right: -5px;
  width: 12px;
  height: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  pointer-events: none;
  /* filter: drop-shadow(0 0 1px rgba(255, 255, 255, 0.85)); */
  border-radius: 999px;
  padding: 2px;
}
.gem-link-highlight-pip svg {
  width: 100%;
  height: 100%;
  display: block;
}

.gem-link-highlight-pip.gem-link-highlight-pip--editable {
  background: rgb(37, 99, 235);
}
.gem-link-highlight-pip--editable {
  color: #fff;
}

.gem-link-highlight-pip.gem-link-highlight-pip--locked  {
  background: rgb(147, 197, 253);
}
.gem-link-highlight-pip--locked {
  color: #fff;
}

.gem-link-highlight-label {
  color: #fff;
  font-size: 10px;
  line-height: 1.2;
  font-family: system-ui, -apple-system, sans-serif;
  text-align: center;
  word-break: break-all;
  padding: 2px 10px;
  max-width: 100%;
  max-height: 100%;
  overflow: hidden;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.75);
  border-radius: 2px;
}
.gem-link-highlight-label--editable {
  background: rgba(37, 99, 235, 0.72);
}
.gem-link-highlight-label--locked {
  background: rgba(147, 197, 253, 0.68);
}
  `.trim();

  let isActive = false;
  let settingEnabled = true;
  let showUrls = false;
  let overlayContainer = null;
  let iframeMutationObserver = null;
  let lifecycleUnsub = null;
  let currentIframe = null;
  let debounceTimer = null;
  let scrollHandler = null;
  let resizeHandler = null;
  let buttonEl = null;

  function debounce(fn, delay = 150) {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(fn, delay);
  }

  function loadSettings(callback) {
    chrome.storage.sync.get({
      [STORAGE_PREVIEW_ENABLED_KEY]: true,
      [STORAGE_SHOW_URLS_KEY]: 'hide-urls',
      [STORAGE_OVERLAY_ACTIVE_KEY]: false,
    }, (result) => {
      settingEnabled = result[STORAGE_PREVIEW_ENABLED_KEY] !== false;
      showUrls = result[STORAGE_SHOW_URLS_KEY] === 'show-urls';
      const overlayActive = result[STORAGE_OVERLAY_ACTIVE_KEY] === true;
      isActive = settingEnabled && overlayActive;
      if (callback) callback();
    });
  }

  chrome.storage.onChanged.addListener((changes, namespace) => {
    if (namespace !== 'sync') return;

    if (changes[STORAGE_PREVIEW_ENABLED_KEY]) {
      settingEnabled = changes[STORAGE_PREVIEW_ENABLED_KEY].newValue !== false;
      if (settingEnabled) {
        chrome.storage.sync.get({ [STORAGE_OVERLAY_ACTIVE_KEY]: false }, (result) => {
          const overlayOn = result[STORAGE_OVERLAY_ACTIVE_KEY] === true;
          isActive = overlayOn;
          if (buttonEl) buttonEl.classList.toggle('e-btn-active', isActive);
          if (isActive) enable();
          else disable();
          syncMenuIndicators();
        });
      } else {
        if (isActive) disable();
        isActive = false;
        if (buttonEl) buttonEl.classList.remove('e-btn-active');
        syncMenuIndicators();
      }
    }

    if (changes[STORAGE_OVERLAY_ACTIVE_KEY] && settingEnabled) {
      isActive = changes[STORAGE_OVERLAY_ACTIVE_KEY].newValue === true;
      if (buttonEl) buttonEl.classList.toggle('e-btn-active', isActive);
      if (isActive) enable();
      else disable();
      syncMenuIndicators();
    }

    if (changes[STORAGE_SHOW_URLS_KEY]) {
      showUrls = changes[STORAGE_SHOW_URLS_KEY].newValue === 'show-urls';
      if (isActive && settingEnabled && currentIframe) {
        debounce(() => renderOverlays(currentIframe));
      }
    }
  });

  function syncMenuIndicators() {
    if (typeof window.gemSyncCompactEmailToolsFeatureMenuItems === 'function') {
      window.gemSyncCompactEmailToolsFeatureMenuItems();
    }
  }

  function injectButton() {
    if (document.getElementById('linkHighlightPreviewButton')) return;

    const anchor = document.querySelector(ANCHOR_SELECTOR);
    if (!anchor) return;

    const buttonGroup = anchor.closest('.e-buttongroup');
    if (!buttonGroup) return;

    const wrapper = document.createElement('e-tooltip');
    wrapper.setAttribute('placement', 'bottom');
    wrapper.setAttribute('content', 'Highlight Links');
    wrapper.innerHTML =
      '<button id="linkHighlightPreviewButton" type="button" class="e-btn e-btn-onlyicon e-svgclickfix" aria-description="" aria-label="Highlight Links">' +
        '<e-icon icon="link"><div aria-hidden="true" class="e-icon-wrapper"><div class="e-icon">&#xF11B;</div></div></e-icon>' +
      '</button>';

    const blockBtn = document.getElementById('blockTargetingPreviewButton');
    if (blockBtn && blockBtn.closest('e-tooltip')) {
      blockBtn.closest('e-tooltip').insertAdjacentElement('beforebegin', wrapper);
    } else {
      const altBtn = document.getElementById('altTextPreviewButton');
      if (altBtn && altBtn.closest('e-tooltip')) {
        altBtn.closest('e-tooltip').insertAdjacentElement('afterend', wrapper);
      } else {
        anchor.insertAdjacentElement('afterend', wrapper);
      }
    }

    buttonEl = wrapper.querySelector('#linkHighlightPreviewButton');
    buttonEl.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      toggle();
    });

    if (settingEnabled && isActive) {
      buttonEl.classList.add('e-btn-active');
    }
  }

  function waitForButtonGroup() {
    if (document.querySelector(BUTTON_GROUP_SELECTOR) && document.querySelector(ANCHOR_SELECTOR)) {
      injectButton();
      return;
    }

    if (typeof window.gemDomWatchWaitFor === 'function') {
      window.gemDomWatchWaitFor(BUTTON_GROUP_SELECTOR, function () {
        if (document.querySelector(ANCHOR_SELECTOR)) injectButton();
      });
    }
  }

  function toggle() {
    if (!settingEnabled) {
      try {
        chrome.storage.sync.set({ [STORAGE_PREVIEW_ENABLED_KEY]: true });
      } catch (_) {}
      return;
    }

    isActive = !isActive;

    if (buttonEl) {
      buttonEl.classList.toggle('e-btn-active', isActive);
    }

    if (isActive) {
      enable();
    } else {
      disable();
    }

    try {
      chrome.storage.sync.set({ [STORAGE_OVERLAY_ACTIVE_KEY]: isActive });
    } catch (_) {}

    syncMenuIndicators();
  }

  function enable() {
    watchIframeLifecycle();
    waitForIframeReady(bindToIframe);
  }

  function disable() {
    if (lifecycleUnsub) {
      lifecycleUnsub();
      lifecycleUnsub = null;
    }
    if (iframeMutationObserver) {
      iframeMutationObserver.disconnect();
      iframeMutationObserver = null;
    }
    removeViewportListeners();
    clearOverlays();
    currentIframe = null;
    clearTimeout(debounceTimer);
    debounceTimer = null;
  }

  function waitForIframeReady(callback) {
    function tryReady() {
      const iframe = document.querySelector(IFRAME_SELECTOR);
      if (!iframe) return false;
      const doc = iframe.contentDocument;
      if (!doc || !doc.body) return false;
      callback(iframe);
      return true;
    }

    if (tryReady()) return;

    if (typeof window.gemDomWatchWaitFor === 'function') {
      window.gemDomWatchWaitFor(IFRAME_SELECTOR, function () {
        tryReady();
      });
    }
  }

  function ensureOverlayStyles(doc) {
    if (!doc || doc.getElementById(STYLE_ID)) return;

    const style = doc.createElement('style');
    style.id = STYLE_ID;
    style.textContent = LINK_HIGHLIGHT_CSS;
    (doc.head || doc.documentElement).appendChild(style);
  }

  function removeOverlayStyles(doc) {
    if (!doc) return;
    const style = doc.getElementById(STYLE_ID);
    if (style) style.remove();
  }

  function ensureOverlayContainer(doc) {
    if (overlayContainer && overlayContainer.ownerDocument === doc && overlayContainer.isConnected) {
      return overlayContainer;
    }

    ensureOverlayStyles(doc);

    overlayContainer = doc.createElement('div');
    overlayContainer.id = OVERLAY_CONTAINER_ID;
    Object.assign(overlayContainer.style, {
      position: 'absolute',
      left: '0',
      top: '0',
      width: '100%',
      height: '100%',
      pointerEvents: 'none',
      zIndex: '999999',
    });

    doc.body.appendChild(overlayContainer);
    return overlayContainer;
  }

  function clearOverlays() {
    if (overlayContainer) {
      const doc = overlayContainer.ownerDocument;
      overlayContainer.remove();
      overlayContainer = null;
      if (doc) removeOverlayStyles(doc);
    }
  }

  function isGemElement(el) {
    if (!el) return false;
    if (el.id && el.id.startsWith('gem-')) return true;
    if (el.classList) {
      for (const cls of el.classList) {
        if (cls.startsWith('gem-')) return true;
      }
    }
    return false;
  }

  function isInsideGemOverlay(node) {
    let el = node.nodeType === 1 ? node : node.parentElement;
    while (el) {
      if (el.id && el.id.startsWith('gem-')) return true;
      el = el.parentElement;
    }
    return false;
  }

  function truncateHref(href, maxLen = 48) {
    const raw = String(href || '').trim();
    if (!raw) return '(no href)';
    if (raw.length <= maxLen) return raw;
    return raw.slice(0, maxLen - 1) + '…';
  }

  function getAnchorId(anchor) {
    if (!anchor._gemLinkHighlightId) {
      anchor._gemLinkHighlightId = 'gem-link-' + Math.random().toString(36).slice(2, 10);
    }
    return anchor._gemLinkHighlightId;
  }

  function isEditableAnchor(anchor) {
    if (!anchor) return false;
    try {
      if (anchor.closest('[e-editable]')) return true;
      if (anchor.querySelector('[e-editable]')) return true;
    } catch (_) {}
    return false;
  }

  function createLinkHighlightPip(doc, editable) {
    const pip = doc.createElement('span');
    pip.className = 'gem-link-highlight-pip gem-link-highlight-pip--' + (editable ? 'editable' : 'locked');
    pip.setAttribute('aria-hidden', 'true');
    pip.innerHTML = editable ? SVG_LINK_EDITABLE : SVG_LINK_LOCKED;
    return pip;
  }

  function renderOverlays(iframe) {
    const doc = iframe.contentDocument;
    if (!doc || !doc.body) return;

    const win = doc.defaultView || iframe.contentWindow;
    if (!win) return;

    const container = ensureOverlayContainer(doc);
    container.innerHTML = '';

    const scrollX = win.scrollX || 0;
    const scrollY = win.scrollY || 0;

    doc.querySelectorAll('a[href]').forEach((anchor) => {
      if (isGemElement(anchor)) return;

      const href = String(anchor.getAttribute('href') || '').trim();
      if (!href) return;

      const rect = anchor.getBoundingClientRect();
      if (!rect.width || !rect.height) return;

      const editable = isEditableAnchor(anchor);
      const variant = editable ? 'editable' : 'locked';

      const overlay = doc.createElement('div');
      overlay.className = 'gem-link-highlight-overlay gem-link-highlight-overlay--' + variant;
      overlay.setAttribute('data-gem-link-id', getAnchorId(anchor));
      overlay.setAttribute('data-gem-link-editable', editable ? 'true' : 'false');
      Object.assign(overlay.style, {
        position: 'absolute',
        left: (rect.left + scrollX) + 'px',
        top: (rect.top + scrollY) + 'px',
        width: rect.width + 'px',
        height: rect.height + 'px',
        pointerEvents: 'none',
        boxSizing: 'border-box',
      });

      overlay.appendChild(createLinkHighlightPip(doc, editable));

      if (showUrls && rect.width >= LABEL_MIN_WIDTH_PX) {
        const label = doc.createElement('span');
        label.className = 'gem-link-highlight-label gem-link-highlight-label--' + variant;
        label.textContent = truncateHref(href);
        overlay.appendChild(label);
      }

      container.appendChild(overlay);
    });
  }

  function removeViewportListeners() {
    if (scrollHandler && currentIframe) {
      try {
        const win = currentIframe.contentWindow;
        if (win) {
          win.removeEventListener('scroll', scrollHandler);
          win.removeEventListener('resize', resizeHandler);
        }
      } catch (_) {}
    }
    scrollHandler = null;
    resizeHandler = null;
  }

  function attachViewportListeners(iframe) {
    removeViewportListeners();

    const win = iframe.contentWindow;
    if (!win) return;

    const onViewportChange = () => {
      if (iframe !== currentIframe || !isActive) return;
      debounce(() => renderOverlays(iframe));
    };

    scrollHandler = onViewportChange;
    resizeHandler = onViewportChange;
    win.addEventListener('scroll', scrollHandler, { passive: true });
    win.addEventListener('resize', resizeHandler);
  }

  function bindToIframe(iframe) {
    currentIframe = iframe;

    const doc = iframe.contentDocument;
    if (!doc || !doc.body) return;

    attachViewportListeners(iframe);
    debounce(() => renderOverlays(iframe));

    if (iframeMutationObserver) {
      iframeMutationObserver.disconnect();
      iframeMutationObserver = null;
    }

    iframeMutationObserver = new MutationObserver((mutations) => {
      if (iframe !== currentIframe) return;

      let onlyOverlayChanges = true;
      for (const m of mutations) {
        if (isInsideGemOverlay(m.target)) continue;

        const hasNonGemNode = (nodes) =>
          Array.from(nodes).some((n) => n.nodeType === 1 && !isGemElement(n));

        if (
          hasNonGemNode(m.addedNodes)
          || hasNonGemNode(m.removedNodes)
          || m.type === 'characterData'
          || m.type === 'attributes'
        ) {
          onlyOverlayChanges = false;
          break;
        }
      }

      if (onlyOverlayChanges) return;

      debounce(() => renderOverlays(iframe));
    });

    iframeMutationObserver.observe(doc.body, {
      childList: true,
      subtree: true,
      characterData: true,
      attributes: true,
    });
  }

  function watchIframeLifecycle() {
    if (lifecycleUnsub) {
      lifecycleUnsub();
      lifecycleUnsub = null;
    }

    if (typeof window.gemDomWatchSubscribe !== 'function') return;

    lifecycleUnsub = window.gemDomWatchSubscribe(function () {
      if (!isActive) return;

      const iframe = document.querySelector(IFRAME_SELECTOR);

      if (!iframe && currentIframe) {
        currentIframe = null;
        clearOverlays();
        if (iframeMutationObserver) {
          iframeMutationObserver.disconnect();
          iframeMutationObserver = null;
        }
        removeViewportListeners();
      }

      if (iframe && iframe !== currentIframe) {
        waitForIframeReady(bindToIframe);
      }
    });
  }

  loadSettings(() => {
    waitForButtonGroup();
    if (isActive) {
      enable();
    }
  });

  window.gemToggleLinkHighlightPreview = function gemToggleLinkHighlightPreview() {
    toggle();
    return isActive;
  };

  window.gemIsLinkHighlightPreviewActive = function gemIsLinkHighlightPreviewActive() {
    return !!(settingEnabled && isActive);
  };
})();
